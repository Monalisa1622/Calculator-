function clearScreen() {
    document.getElementById("screen").value = "";
}

function deleteLast() {
    let screenValue = document.getElementById("screen").value;
    document.getElementById("screen").value = screenValue.slice(0, -1);
}

function appendSymbol(symbol) {
    document.getElementById("screen").value += symbol;
}

function calculate() {
    let expression = document.getElementById("screen").value;
    try {
        document.getElementById("screen").value = eval(expression);
    } catch {
        document.getElementById("screen").value = "Error";
    }
}
